mkdir -p /data/xuht/eventy_detection/event/model/
mkdir -p /data/xuht/eventy_detection/event/model/
mkdir -p /data/xuht/bert/chinese_L-12_H-768_A-12/
