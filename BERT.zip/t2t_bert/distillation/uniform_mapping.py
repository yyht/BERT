
import tensorflow as tf
import numpy as np
from utils.bert import bert_utils

def attention_score_matching(teacher_score, student_score, mapping_method="uniform"):

	# Scalar dimensions referenced here:
	#   B = batch size (number of sequences)
	#   F = `from_tensor` sequence length
	#   T = `to_tensor` sequence length
	#   N = `num_attention_heads`
	#   H = `size_per_head`

	# Take the dot product between "query" and "key" to get the raw
	# attention scores.
	# `attention_scores` = [B, N, F, T]

	with tf.variable_scope("bert"+"/attention_weights", reuse=tf.AUTO_REUSE): 
		projection_weights = tf.get_variable(
				"attention_score_weights", [len(student_score)*len(teacher_score)],
				initializer=tf.random_uniform_initializer(minval=0.0, maxval=1.0))

	loss = tf.constant(0.0)
	for i in range(len(student_score)):
		student_score_ = student_score[i]
		for j in range(len(teacher_score)):
			teacher_score_ = teacher_score[j]
			weight = projection_weights[i*len(teacher_score)+j]

			loss += weight*tf.reduce_mean(tf.sqrt(tf.reduce_sum(tf.pow(student_score_-teacher_score_, 2.0), axis=(1))))
	loss /= (len(student_score)*len(teacher_score))
	return loss

def hidden_matching(teacher_hidden, student_hidden):

	teacher_shape = bert_utils.get_shape_list(teacher_hidden[0], expected_rank=[3])
	student_shape = bert_utils.get_shape_list(student_hidden[0], expected_rank=[3])

	with tf.variable_scope("bert"+"/hidden_weights", reuse=tf.AUTO_REUSE): 
		projection_weights = tf.get_variable(
				"hidden_weights", [len(student_hidden)*len(teacher_hidden)],
				initializer=tf.random_uniform_initializer(minval=0.0, maxval=1.0))

	# B X F X H

	def projection_fn(input_tensor):

		with tf.variable_scope("bert"+"/uniformal_mapping/projection", reuse=tf.AUTO_REUSE): 
			projection_weights = tf.get_variable(
				"output_weights", [student_shape[-1], teacher_shape[-1]],
				initializer=tf.truncated_normal_initializer(stddev=0.02))

			input_tensor_projection = tf.einsum("abc,cd->abd", input_tensor, 
												projection_weights)
			return input_tensor_projection

	loss = tf.constant(0.0)
	for i in range(len(student_hidden)):
		student_hidden_ = student_hidden[i]
		student_hidden_ = projection_fn(student_hidden_)
		for j in range(len(teacher_hidden)):
			teacher_hidden_ = teacher_hidden[j]
			weight = projection_weights[i*len(teacher_hidden)+j]
			loss += weight*tf.reduce_mean(tf.sqrt(tf.reduce_sum(tf.pow(student_hidden_-teacher_hidden_, 2.0), axis=(2))))
	loss /= (len(student_hidden)*len(teacher_hidden))
	return loss 


