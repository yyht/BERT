mpirun -np 1 \
 -H localhost:2 \
 python test_hornord_distributed.py
