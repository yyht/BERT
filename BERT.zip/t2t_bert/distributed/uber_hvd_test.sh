mpirun -np 2 \
 -H localhost:2 \
 python ./t2t_bert/distributed/uber_mnist_estimator.py

