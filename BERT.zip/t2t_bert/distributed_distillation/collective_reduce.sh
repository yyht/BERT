odpscmd=$1
model_folder=$2
model_zip=$3
model_type=$4

if [ ! -f ${model_zip} ]
then
  rm ${model_zip}
fi

zip -r ${model_zip} ${model_folder} -x "*.DS_Store,*.git*" 

pai_command="
# set odps.running.cluster=AY100G;
# set odps.algo.hybrid.deploy.info=LABEL:V100:OPER_EQUAL;
# -DautoStrategy='true'
# -DenableJITDeviceTuning='false'
# -DautoGPUSelect='false'
pai -name tensorflow1120
	-project algo_public_dev 
	-Dscript='file://${model_zip}'
	-DjobName='bert_mrc_pretrain'
	-Dtags='bert'
	-DmaxHungTimeBeforeGCInSeconds=0
	-DentryFile='./BERT/t2t_bert/distributed_bin/collective_reduce_train_eval_api.py' 
	-Dcluster='{\"worker\":{\"count\":4, \"gpu\":100}}'
	-DhyperParameters='file:///Users/xuhaotian/Desktop/my_work/BERT/t2t_bert/distributed_distillation/knowledge_distillation_train_porn'
	-Dbuckets='oss://alg-misc/BERT/?role_arn=acs:ram::1265628042679515:role/yuefeng2&host=cn-hangzhou.oss-internal.aliyun-inc.com';
"
echo "${pai_command}"
${odpscmd} -e "${pai_command}"
echo "finish..."

