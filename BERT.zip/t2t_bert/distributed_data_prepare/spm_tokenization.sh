python ./t2t_bert/distributed_data_prepare/spm_tokenization.py \
	--train_file \
	--output_file \
	--word_piece_model \
	
