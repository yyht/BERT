python create_pretraining_data.py --input_file /data/xuht/guangfa/bert/finicial_new_test.txt --output_file /data/xuht/guangfa/bert/pretrain_finicial_new.tfrecords --vocab_file /data/xuht/guangfa/chinese_L-12_H-768_A-12/vocab.txt

